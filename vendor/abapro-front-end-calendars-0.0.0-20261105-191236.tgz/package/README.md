# @abapro-front-end/calendars

Weekly availability and annual work calendars for ABAPRO portals. Two React components, one design, bundled English and Arabic copy, and no opinion about where the data lives.

- `WeeklyCalendar`: seven days in 15-minute slots from 06:00 to 24:00. Click or drag to paint Available, Unavailable or Online-only; click a day name for a day off; rules are checked live. Day names are two letters (`MO`, `TU`, ...; full names in Arabic) and screen readers hear the full name.
- `AnnualCalendar`: a year grid where whole days are marked off; rules are checked live.

Requirements: React 19, Tailwind CSS v4 in the consuming app.

## Install

> **Temporary process.** The package is not published yet. Until its first release reaches the GitLab npm registry, portals install a tarball (`.tgz`) that is committed to their own repo. Once it is published, switch to the registry as described in [After the first release](#after-the-first-release-install-from-the-registry). Imports and styles stay the same; only the install source changes.

### Install from the tarball

1. Get the latest tarball in one of two ways. Either way it is named after its build time, for example `abapro-front-end-calendars-0.0.0-20261020-071921.tgz`.
   - **From the maintainers:** ask the calendar maintainers for the current build.
   - **Build it yourself:** with access to the GitLab repo, clone it and pack `main` (Node 24 via `nvm`):

     ```sh
     git clone git@gitlab.com:abapro-front-end/abapro-calendar.git
     cd abapro-calendar
     nvm use
     npm ci
     npm run pack:local
     ```

     The tarball is written to `.packs/`. Build from `main` so every portal runs the same code; a build from your own branch is for local testing only.
2. In the portal repo, put it in a `vendor/` folder and install it from there:

   ```sh
   mkdir -p vendor
   cp <path>/abapro-front-end-calendars-<version>-<stamp>.tgz vendor/
   npm install ./vendor/abapro-front-end-calendars-<version>-<stamp>.tgz
   ```

   npm records it in `package.json` as `"@abapro-front-end/calendars": "file:vendor/<tarball>.tgz"`.
3. Add the theme and framework setup from [Styles and framework setup](#styles-and-framework-setup).
4. Commit the tarball, `package.json` and `package-lock.json` together. Deploys install from the committed file, so CI and hosting need no token or registry access.

Keep in mind:

- The tarball must live inside the portal repo. A path outside it (`npm install ../abapro-calendar/.packs/...`) works on your machine but breaks every deploy.
- Make sure the portal's `.gitignore` does not exclude `vendor/` or `*.tgz`.
- Install the `.tgz` file, never the package folder. `npm link` and `file:` folder paths symlink the package, which then loads its own copy of React.

### Update to a newer build

Each build has its own file name. Get the new one from the maintainers, or rebuild it in your clone of this repo:

```sh
git checkout main
git pull
npm ci
npm run pack:local
```

Then replace the old tarball in the portal:

```sh
rm -f vendor/abapro-front-end-calendars-*.tgz
cp <path>/abapro-front-end-calendars-<version>-<new stamp>.tgz vendor/
npm install ./vendor/abapro-front-end-calendars-<version>-<new stamp>.tgz
```

Then check the calendar pages, apply any breaking changes (for example a renamed prop or message key; see the maintainers' change note, or the commits since your last build), and commit the tarball, `package.json` and `package-lock.json` together.

Never replace a tarball under the same file name. Machines that installed the old one keep it from npm's cache without any error, while a fresh deploy fails with `EINTEGRITY`.

### Styles and framework setup

The components are styled with Tailwind utility classes, which your app's Tailwind build generates. Do these steps once per portal.

**1. Import the theme (required).** In your Tailwind entry stylesheet, the CSS file that contains `@import "tailwindcss"` (in Next.js usually `app/globals.css`), add the theme import right after it:

```css
@import "tailwindcss";
@import "@abapro-front-end/calendars/theme.css";
```

`theme.css` brings the `cal-*` colour tokens, the fonts and the animations, and it tells Tailwind to scan the package's `dist/` folder for the classes the components use. That is all most portals need; the admin dashboard uses exactly this.

**2. Check the result.** Render a calendar (see [Usage](#usage)). If the grid shows its grey and red cells, rounded corners and the purple accent, you are done. If it renders unstyled, Tailwind did not scan the package, so add a `@source` line to the same stylesheet, with the path written relative to that CSS file:

```css
@source "../node_modules/@abapro-front-end/calendars/dist";
```

`../node_modules/...` fits `app/globals.css`; for `src/app/globals.css` use `../../node_modules/...`.

**3. Next.js with Jest only.** If the portal runs Jest through `next/jest` and any test renders the calendars, list the package in `transpilePackages` in `next.config.ts`:

```ts
import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  transpilePackages: ["@abapro-front-end/calendars"],
};

export default nextConfig;
```

The package ships ESM only, and `next/jest` skips transforming `node_modules` unless a package is listed here, so Jest would fail with `SyntaxError: Cannot use import statement outside a module`. The Next.js app itself builds without this setting, and it is harmless to add. Other frameworks (Vite and similar) need no extra step.

**4. Optional: match your brand.** Map the `--cal-*` tokens to your portal's own colours and fonts, as described in [Theming](#theming).

### After the first release: install from the registry

Once a version is published to the GitLab Package Registry of [abapro-front-end/abapro-calendar](https://gitlab.com/abapro-front-end/abapro-calendar), the tarball process ends.

1. Get a deploy token with the `read_package_registry` scope from an `abapro-front-end` group Owner.
2. Once per machine, authenticate:

   ```sh
   npm config set //gitlab.com/api/v4/packages/npm/:_authToken=<token>
   ```

3. In the portal repo, map the scope and replace the tarball with the published version:

   ```sh
   echo "@abapro-front-end:registry=https://gitlab.com/api/v4/packages/npm/" >> .npmrc
   npm install @abapro-front-end/calendars@^0.1.0
   rm -f vendor/abapro-front-end-calendars-*.tgz
   ```

   Commit `.npmrc`, `package.json`, `package-lock.json` and the removed tarball together. Imports, `theme.css` and the Next.js setup stay unchanged.
4. Give every deploy the token. In GitLab CI, run the `npm config set` line with a masked CI/CD variable before `npm ci`. On Vercel, set an `NPM_RC` environment variable to the scope line plus `//gitlab.com/api/v4/packages/npm/:_authToken=<token>`.

The repo-level `.npmrc` only maps the scope. Never commit a token line, and never commit `${NPM_TOKEN}`: npm aborts every command when the variable is unset.

## Usage

Both calendars are controlled: your app owns the schedule and passes each `onChange` result back through `value`. The examples below include **every public prop** for each calendar. Optional props can be omitted to use the defaults.

These examples use Sonner for notifications (`npm install sonner` in your app). Sonner is optional; connect `onNotify` to your existing toast system instead if you have one. Mount one `<Toaster />` in your app layout if you already share it across pages.

### Weekly example with all props

```tsx
"use client";

import { useState } from "react";
import { toast, Toaster } from "sonner";
import {
  WeeklyCalendar,
  emptyWeek,
  type CalendarNotice,
  type WeeklyRules,
  type WeeklySchedule,
} from "@abapro-front-end/calendars";

const therapistRules: WeeklyRules = {
  minBlockInPersonMins: 60,
  minBlockOnlineMins: 60,
  minBreakMins: 15,
  continuousWindowMins: 360,
  maxDaysOff: 2,
  minAdjacentUnavailMins: 15,
  supportsOnline: false,
  mirrorWorkdays: true,
  travelTime: { required: true, options: [45, 60, 75, 90, 105] },
};

export function WeeklySchedulePage() {
  const [week, setWeek] = useState<WeeklySchedule>(() => emptyWeek());
  const [rules, setRules] = useState<WeeklyRules>(therapistRules);

  function handleChange(next: WeeklySchedule) {
    setWeek(next); // Required: feed accepted edits back to the calendar.
  }

  function handleRulesChange(next: WeeklyRules) {
    setRules(next); // Apply the Rules dialog's new settings.
  }

  function handleSave(value: WeeklySchedule, effectiveRules: WeeklyRules) {
    // Demo persistence in this browser only; replace with your backend call.
    localStorage.setItem("therapist-weekly", JSON.stringify({ value, rules: effectiveRules }));
  }

  function handleNotify(notice: CalendarNotice) {
    toast[notice.kind](notice.message, { style: { whiteSpace: "pre-line" } });
  }

  return (
    <>
      <Toaster />
      <WeeklyCalendar
        value={week}
        onChange={handleChange}
        rules={rules}
        baseRules={therapistRules}
        onSave={handleSave}
        onRulesChange={handleRulesChange}
        locale="en"
        dir="ltr"
        messages={{
          common: { save: "Save schedule" },
          weekly: {
            title: "Select your weekly business hours as a Therapist",
            notice: {
              travelBody1: "Please select for the Therapist your preferred <hl>TRAVEL TIME</hl> option",
            },
          },
        }}
        onNotify={handleNotify}
        className="mx-auto w-full max-w-5xl rounded-xl border border-cal-border p-4"
      />
    </>
  );
}
```

`onChange` updates the local draft; it does not automatically persist data. `onSave` is called only after the full week passes validation and may return `void` or a `Promise<void>`. Supplying it displays the weekly Save / Reset / Rules bar. The example writes to browser storage but does not load previous data on mount; your app should load its saved schedule and use it as `value`.

### Annual example with all props

```tsx
"use client";

import { useState } from "react";
import { toast, Toaster } from "sonner";
import {
  AnnualCalendar,
  type AnnualRules,
  type AnnualSchedule,
  type CalendarNotice,
} from "@abapro-front-end/calendars";

const analystRules: AnnualRules = {
  maxDaysOffPerYear: 56,
  maxConsecutiveDays: 28,
  minGapWeeks: 4,
};

export function AnnualSchedulePage() {
  const [daysOff, setDaysOff] = useState<AnnualSchedule>(["2027-06-14", "2027-06-15"]);

  function handleChange(next: AnnualSchedule) {
    setDaysOff(next); // Includes selections from every year, not just the visible one.
  }

  function handleNotify(notice: CalendarNotice) {
    toast[notice.kind](notice.message, { style: { whiteSpace: "pre-line" } });
  }

  function saveAnnualSchedule() {
    // AnnualCalendar has no onSave prop: your app chooses when to persist.
    localStorage.setItem("analyst-annual", JSON.stringify(daysOff));
    toast.success("Annual schedule saved");
  }

  return (
    <>
      <Toaster />
      <AnnualCalendar
        value={daysOff}
        onChange={handleChange}
        rules={analystRules}
        years={[2027, 2028]}
        today="2027-01-01"
        locale="en"
        dir="ltr"
        messages={{
          annual: {
            title: "Select your annual work calendar\nas a Behavior Analyst",
            guidelines: { title: "Setting up Analyst annual work calendar" },
          },
        }}
        onNotify={handleNotify}
        className="mx-auto w-full max-w-5xl rounded-xl border border-cal-border p-4"
      />
      <button type="button" onClick={saveAnnualSchedule}>Save annual schedule</button>
    </>
  );
}
```

The fixed `today` and `years` make this example reproducible. In production, omit them to use the browser's current date and the current/next year, or pass the business date and allowed years from your app. Dates earlier than `today` are locked. Switching years preserves selected dates and does not call `onChange`.

### Props shared by both

| Prop | Default | Shape and example |
|---|---|---|
| `locale` | `"en"` | A locale string, e.g. `locale="ar"`. Selects bundled EN/AR copy and localized date labels; other languages fall back to English copy. |
| `dir` | inferred from `locale` | `"ltr"` or `"rtl"`, e.g. `dir="rtl"`. Overrides layout direction, dialogs included, not the language. |
| `messages` | bundled copy | `DeepPartial<CalendarMessages>`, e.g. `messages={{ common: { save: "Save schedule" }, weekly: { title: "My availability" } }}`. Omitted nested keys keep their defaults. |
| `onNotify` | inline status messages | `(notice: CalendarNotice) => void`, e.g. `onNotify={(notice) => toast[notice.kind](notice.message)}`. Replaces the inline status renderer; it does not replace confirmation or guideline dialogs. |
| `theme` | package defaults | `CalendarTheme`, e.g. `theme={{ accent: "var(--primary)", unavailable: "#e11d48" }}`. Overrides only the tokens you pass, for this calendar and its dialogs; see [Theming](#theming). |
| `portalContainer` | `<body>` | `CalendarPortalContainer`: an `HTMLElement`, a ref to one, or `null`, e.g. `portalContainer={popupHost}`. Where dialogs, select menus and the year indicator render; see [Inside a modal or full-screen window](#inside-a-modal-or-full-screen-window). |
| `className` | none | A root CSS class string, e.g. `className="mx-auto max-w-5xl p-4"`. Does not style portal dialogs; use `theme` for those. |

A notification has this shape:

```ts
import type { CalendarNotice } from "@abapro-front-end/calendars";

const notice: CalendarNotice = {
  kind: "error", // "error" | "info" | "success"
  message: "You can select up to 56 days off per year",
  violation: { // Optional; informational/success notices often omit it.
    id: "max-days-off",
    values: { max: 56 },
  },
};
```

`violation.id` is one of `min-block`, `online-block`, `breaks`, `window`, `max-days-off`, `max-consecutive`, or `min-gap`. `values` contains rule-specific numeric parameters. Optional `offending` contains slot indices (`number[]`) or annual dates (`string[]`); check for its presence before using it.

### Inside a modal or full-screen window

Dialogs (guidelines, notices, the travel-time confirmation, rules, demo, year picker), their select menus and the annual year indicator render in a portal at the end of `<body>`. When the calendar sits inside a modal or full-screen window that traps focus or blocks clicks outside itself, those popups open behind it and can't be clicked. Pass `portalContainer` an element inside that window and they render there instead:

```tsx
import { useState } from "react";

const [popupHost, setPopupHost] = useState<HTMLDivElement | null>(null);

<FullScreenWindow>
  <div ref={setPopupHost}>
    <WeeklyCalendar value={week} onChange={setWeek} portalContainer={popupHost} />
  </div>
</FullScreenWindow>;
```

- `null` holds the popups back until the element exists, so the state pattern above never flashes a popup on `<body>`. Leaving the prop out keeps `<body>`.
- A `useRef` object works too; while `ref.current` is empty the popups fall back to `<body>`.
- The popups use `position: fixed`. Inside an element with `transform`, `filter` or `contain`, they are placed against that element instead of the viewport. For a full-screen window this looks the same.

### WeeklyCalendar props and schedule shape

| Prop | Default | Shape and example |
|---|---|---|
| `value` | required | `WeeklySchedule`; start with `emptyWeek()` or use the object below. |
| `onChange` | required | `(next: WeeklySchedule) => void`; `onChange={setWeek}` or update state in `handleChange(next)`. Fires after accepted edits, resets, and confirmed travel-time changes. |
| `rules` | `defaultWeeklyRules` | A complete `WeeklyRules` object, such as `therapistRules` above. To change only a few fields, spread `defaultWeeklyRules` first. |
| `baseRules` | `defaultWeeklyRules` | A complete `WeeklyRules` object used by **Reset inside the Rules dialog**, e.g. `baseRules={therapistRules}`. It is not the current rules or a saved schedule. There is no `pageRules` prop. |
| `onSave` | absent | `(value: WeeklySchedule, rules: WeeklyRules) => void \| Promise<void>`; see `handleSave` above. Receives effective rules, including the selected travel time as the minimum break. Does not fire when validation fails. |
| `onRulesChange` | absent | `(next: WeeklyRules) => void`; `onRulesChange={setRules}`. Called when the Rules dialog applies changes. Pass the new object back through `rules`. |

```ts
import type { WeeklySchedule } from "@abapro-front-end/calendars";

const week: WeeklySchedule = {
  days: [
    { blocks: [{ start: 0, end: 12, kind: "unavailable" }] }, // Monday: 06:00–09:00
    { blocks: [{ start: 0, end: 12, kind: "unavailable" }] }, // Tuesday
    { blocks: [{ start: 0, end: 12, kind: "unavailable" }] }, // Wednesday
    { blocks: [{ start: 0, end: 12, kind: "unavailable" }] }, // Thursday
    { blocks: [{ start: 0, end: 12, kind: "unavailable" }] }, // Friday
    { blocks: [{ start: 0, end: 12, kind: "unavailable" }] }, // Saturday
    { blocks: [{ start: 0, end: 72, kind: "unavailable" }] }, // Sunday: day off
  ],
  daysOff: [6], // Monday = 0, Sunday = 6
  travelTimeMins: 45, // null until selected; must match an allowed option
};
```

There are exactly seven days, Monday first. Each slot is 15 minutes: `0 = 06:00`, `12 = 09:00`, and `72 = 24:00`. Blocks use an inclusive `start` and exclusive `end`. Block `kind` is `"unavailable"` or `"online"`; uncovered slots are available in person. An online block such as `{ start: 12, end: 16, kind: "online" }` represents 09:00–10:00 and requires `supportsOnline: true`. `emptyWeek()` means maximum availability, with no days off and no selected travel time.

Keep blocks ordered and non-overlapping. When loading a saved schedule, keep `daysOff` and the corresponding full-day unavailable blocks consistent. With `mirrorWorkdays: true`, normal workdays should share the same blocks; the calendar mirrors subsequent edits to those days. In the object above, all six workdays are available from 09:00 to 24:00. Apply your business rules when constructing initial schedules.

| Weekly rule | Default | Meaning / example |
|---|---|---|
| `minBlockInPersonMins` | `60` | Minimum in-person availability block, e.g. `60` for one hour. |
| `minBlockOnlineMins` | `30` | Minimum online-only block; used when online availability is enabled. |
| `minBreakMins` | `15` | Minimum internal unavailable gap; overridden by a selected travel time. An explicit `0` disables this gap rule even when travel time is selected. |
| `continuousWindowMins` | `180` | Required continuous availability window on workdays; e.g. `360` for six hours. |
| `maxDaysOff` | `2` | Maximum weekly days off. |
| `minAdjacentUnavailMins` | `15` | Minimum unavailable block at the start or end of the day. |
| `supportsOnline` | `false` | `true` adds the online-only status. |
| `mirrorWorkdays` | `true` | `true` copies workday edits to all non-day-off days; `false` edits days independently. |
| `travelTime` | required; `[45, 60, 75, 90, 105]` | `{ required: true, options: [45, 60] }` requires a choice before editing. `null` removes the selector. Use a nonempty array of valid minute values when enabled. |

Changing travel time clears availability edits and days off after confirmation if a schedule exists. Cancelling preserves the current schedule.

### AnnualCalendar props and schedule shape

| Prop | Default | Shape and example |
|---|---|---|
| `value` | required | `AnnualSchedule`, a sorted array of local date strings, e.g. `["2027-06-14", "2027-06-15"]`. `[]` means no leave days. |
| `onChange` | required | `(next: AnnualSchedule) => void`; `onChange={setDaysOff}`. Receives the complete sorted selection after an accepted click or drag. Rejected edits notify without changing the value. |
| `rules` | `defaultAnnualRules` | `{ maxDaysOffPerYear: 56, maxConsecutiveDays: 0, minGapWeeks: 0 }`. Pass a full object or spread the defaults. |
| `years` | current and next year | An array such as `[2027, 2028]`. The year button cycles in this order; a single year disables switching. Use unique years and a nonempty array. |
| `today` | browser's local date | A date string such as `"2027-01-01"`; earlier dates cannot be edited. Use `yyyy-MM-dd`, not a timestamp. |

| Annual rule | Default | Meaning / example |
|---|---|---|
| `maxDaysOffPerYear` | `56` | Maximum selected leave days per calendar year. `0` disables the limit. |
| `maxConsecutiveDays` | `0` | Maximum consecutive leave dates, e.g. `28`. `0` disables the limit. |
| `minGapWeeks` | `0` | Minimum full Monday–Sunday weeks between separate leave blocks, e.g. `4`. `0` disables the limit. |

AnnualCalendar has no `baseRules`, `onSave`, or `onRulesChange` props. To change annual rules, update your app's state and pass the next `rules` object. To save, use your own button (as above) or connect a data adapter. For automatic backend saves, serialize writes so older requests cannot overwrite newer edits; `useSchedule` already provides that behavior.

## Rule sets

The package knows no roles. `defaultWeeklyRules` is an in-person-only set (60 min blocks, a 3 h window, 2 days off) with required travel-time selection: 45, 60, 75, 90 or 105 minutes. The selected travel time becomes the minimum break between availability blocks; edge breaks can be 15 minutes. Portals pass their own sets:

```ts
const therapist: WeeklyRules = {
  ...defaultWeeklyRules,
  continuousWindowMins: 360,
  travelTime: { required: true, options: [45, 60, 75, 90, 105] },
};
```

With `travelTime.required: true` (the default), the specialist must pick a travel time before painting. Set `travelTime: null` to hide the selector and use `minBreakMins` instead, or supply your own options. With `supportsOnline: true` the paint cycle gains Online-only and the guidelines gain the online card.

### Rule helpers

Portals that let admins edit rule sets can reuse the package's checks instead of copying them:

- `MINUTE_CHOICES` lists every duration a rule can take (15 to 1080 minutes in 15-minute slots); `isSlotDuration(minutes, maximum?)` checks one value. `maximum` defaults to `MAX_DAY_MINUTES` (1080, the editable 06:00-24:00 day).
- `validateWeeklyRules(rules, limits?)` and `validateAnnualRules(rules, limits?)` return `RuleIssue[]` (`{ path, code }`), never text, so each portal words the problems in its own language. Codes: `wholeNumber`, `minutesRange`, `daysPerWeek`, `daysPerYear`, `weeksRange`, `windowTooShort`, `travelEmpty`, `travelRange`, `travelDuplicate`.
- `DEFAULT_RULE_LIMITS` holds the caps the validators use (travel choices up to 240 minutes, 7 days off a week, 366 days off a year, 366 consecutive days off, 52 weeks of gap); pass your own `RuleLimits` to change them.
- `WEEKLY_NUMERIC_RULES` / `ANNUAL_NUMERIC_RULES` name the numeric rules; `bypassWeeklyRules(rules, off)` and `bypassAnnualRules(rules, off)` turn the listed rules off without changing the original set: the weekly days-off limit becomes 7, every other listed rule becomes 0 (which switches it off).
- `formatGuidelineDuration(minutes, locale)` words a duration the way the guidelines do ("2 hours 45 min").

## Messages

Bundled copy is role-neutral. Override known message keys through `messages`; missing keys keep the bundled text. Use `DeepPartial<CalendarMessages>` for type-checked overrides.

```ts
import type { CalendarMessages, DeepPartial } from "@abapro-front-end/calendars";

const customMessages: DeepPartial<CalendarMessages> = {
  common: { save: "Save schedule", cancel: "Keep editing" },
  weekly: {
    title: "My weekly availability",
    controls: { travelPrompt: "Choose your travel time" },
    notice: { travelBody1: "Please choose a <hl>TRAVEL TIME</hl> option" },
  },
  annual: {
    title: "My annual leave calendar",
    rules: {
      maxDaysOff: {
        label: "Annual leave limit",
        message: "Choose no more than {max} leave days per year",
      },
    },
  },
};
// Pass messages={customMessages} to either calendar.
```

Messages are strings, not JSX. In supported rich-text fields, `<hl>...</hl>` marks highlighted text. Annual guideline booking text also supports `<sqCompleted></sqCompleted>` and `<sqScheduled></sqScheduled>` markers. Keep each template's placeholder names (such as `{max}`) when rewriting it so runtime values can still be inserted. Translate the strings in your own app before passing them; you do not need to replace the entire messages object.

Arabic copy was adapted from the admin portal with role words removed. A native-speaker review of `src/messages/ar.ts` is still open.

### Complete message reference

Every string in `CalendarMessages` is listed below, grouped by its object path. Keys use dotted notation for reference only: override `weekly.controls.travelPrompt` with `messages={{ weekly: { controls: { travelPrompt: "Your text" } } }}`, not a flat key named `"weekly.controls.travelPrompt"`. Override only what you need; the remaining strings come from the selected locale.

The tables show the **package's English defaults**, not the role-specific overrides in the playground or Admin Dashboard. Arabic has the same keys. You can inspect or reuse either complete object:

```ts
import { en, ar, messagesFor, type CalendarMessages } from "@abapro-front-end/calendars/messages";

const english: CalendarMessages = en;
const arabic: CalendarMessages = ar;
const selected: CalendarMessages = messagesFor("ar-SA"); // Arabic; other languages fall back to English.
// Read these objects or copy them; do not mutate shared bundled defaults.
```

In the tables, `\n` denotes a newline in the default string. Whether it renders as a line break depends on the component; notification paragraphs wrap naturally. `—` means there are no placeholders or rich-text tags in that default.

| Placeholder | Value supplied by the calendar |
|---|---|
| `{max}` | Maximum days off or maximum consecutive days, depending on the rule/message. |
| `{issues}` | The formatted list of weekday names and failed weekly rule labels. |
| `{dur}` | Formatted minimum block length or continuous availability duration. |
| `{brk}` | Formatted minimum break, including the selected travel time when applicable. |
| `{edge}` | Formatted minimum unavailable duration at the start/end of the day. |
| `{count}` | Number of days for `rulesDialog.dayOne` / `dayOther`; the calendar chooses the plural form. |
| `{travelMin}` | Minimum travel-time option, formatted for guideline prose (e.g. `00h45m`). |
| `{maxDaysOff}` | Maximum weekly days off. |
| `{window}` | Formatted continuous availability window for guideline prose. |
| `{minBlock}` / `{minOnline}` | Formatted minimum in-person / online availability block for guideline prose. |
| `{minBreak}` | Formatted minimum break for guideline prose. |
| `{weeks}` | Minimum gap in full weeks for the annual rule notification. |
| `{maxDaysOffPerYear}` | Annual leave-day limit for the guidelines. |
| `{maxConsecutive}` | Maximum consecutive leave days for the guidelines. |
| `{minGapWeeks}` | Minimum full-week gap for the annual guidelines. |

Use the placeholders listed for the particular message; arbitrary names such as `{role}` are not automatically substituted. For role-specific titles, build the final string in your app before passing it.

`<hl>...</hl>` highlights text in guideline bodies and the weekly `maxAvailBody` / `travelBody1` notices. `<sqCompleted></sqCompleted>` and `<sqScheduled></sqScheduled>` add booking-status color markers in annual guideline bodies. These are supported message tags, not arbitrary HTML; plain titles, labels, and toast messages do not parse them.

In right-to-left copy, a clock range such as `06:00–24:00` is displayed backwards (`24:00–06:00`) unless it is wrapped in two invisible Unicode characters: U+2066 (left-to-right isolate) before it and U+2069 (pop directional isolate) after it. The bundled Arabic `maxAvailBody` does this; in a JavaScript string write them as escapes, e.g. `"... \u206606:00–24:00\u2069 ..."`. Keep them when you override Arabic text that contains times. The grid's own time labels are already fixed to left-to-right.

Some keys are conditional: online controls require `supportsOnline`; travel notices require travel-time selection; annual consecutive/gap cards require their limits to be enabled. `annual.yearPickerTitle` is used by the optional year-picker dialog; the default calendar switches years directly. `weekly.saveBar.issueWeekdays` is exported but currently not read by the built-in UI.

<details>
<summary>common — 9 messages</summary>

| Key | Default English text | Placeholders / tags |
|---|---|---|
| `common.save` | `Save` | — |
| `common.cancel` | `Cancel` | — |
| `common.close` | `Close` | — |
| `common.ok` | `OK` | — |
| `common.checkGuidelines` | `We recommend checking these guidelines` | — |
| `common.collapse` | `Collapse` | — |
| `common.expand` | `Expand` | — |
| `common.hourShort` | `h` | — |
| `common.minuteShort` | `m` | — |

</details>

<details>
<summary>weekly — 2 messages</summary>

| Key | Default English text | Placeholders / tags |
|---|---|---|
| `weekly.title` | `Select your weekly business hours` | — |
| `weekly.help` | `How editing works` | — |

</details>

<details>
<summary>weekly.controls — 8 messages</summary>

| Key | Default English text | Placeholders / tags |
|---|---|---|
| `weekly.controls.travelPrompt` | `Choose the optimal travel time between your clients` | — |
| `weekly.controls.paintInstr` | `Click a time slot to change its status; drag to paint several` | — |
| `weekly.controls.availableLabel` | `Available In-person` | — |
| `weekly.controls.unavailableLabel` | `Unavailable` | — |
| `weekly.controls.onlineLabel` | `Available Online-only` | — |
| `weekly.controls.availableDesc` | `Clients who need your services during these hours will be able to find you` | — |
| `weekly.controls.unavailableDesc` | `Clients who need your services during these hours won't be able to find you` | — |
| `weekly.controls.onlineDesc` | `Only clients who agreed to online sessions can find or book you during these hours` | — |

</details>

<details>
<summary>weekly.notice — 8 messages</summary>

| Key | Default English text | Placeholders / tags |
|---|---|---|
| `weekly.notice.travelChangeTitle` | `Change travel time?` | — |
| `weekly.notice.travelChangeBody` | `Changing travel time will clear your entire weekly schedule, including availability changes and days off. This cannot be undone. Do you want to continue?` | — |
| `weekly.notice.travelChangeConfirm` | `Change and reset` | — |
| `weekly.notice.maxAvailTitle` | `Business hours set to maximum availability` | — |
| `weekly.notice.maxAvailBody` | `Your weekly business hours are set to <hl>maximum availability 06:00–24:00, MO–SU</hl>. You can change them until the first booking for your services is confirmed.` | `<hl>` |
| `weekly.notice.travelTitle` | `Select a travel time` | — |
| `weekly.notice.travelBody1` | `Please select your preferred <hl>TRAVEL TIME</hl> option` | `<hl>` |
| `weekly.notice.travelBody2` | `You can change it later until the first booking for your services is confirmed` | — |

</details>

<details>
<summary>weekly.saveBar — 8 messages</summary>

| Key | Default English text | Placeholders / tags |
|---|---|---|
| `weekly.saveBar.rules` | `Rules` | — |
| `weekly.saveBar.reset` | `Reset` | — |
| `weekly.saveBar.daysOffMax` | `Maximum {max} days off allowed` | `{max}` |
| `weekly.saveBar.travelReset` | `Travel time updated - calendar reset` | — |
| `weekly.saveBar.rulesUpdated` | `Calendar rules updated` | — |
| `weekly.saveBar.saved` | `Availability saved` | — |
| `weekly.saveBar.issueWeekdays` | `Weekdays` | — |
| `weekly.saveBar.cantSave` | `Can't save - {issues}` | `{issues}` |

</details>

<details>
<summary>weekly.rules — 12 messages</summary>

| Key | Default English text | Placeholders / tags |
|---|---|---|
| `weekly.rules.minBlock.inPerson.label` | `In-person availability block` | — |
| `weekly.rules.minBlock.inPerson.message` | `Each in-person availability block must be at least {dur}.` | `{dur}` |
| `weekly.rules.minBlock.any.label` | `Minimum availability block` | — |
| `weekly.rules.minBlock.any.message` | `Each availability block must be at least {dur}.` | `{dur}` |
| `weekly.rules.onlineBlock.label` | `Online-only availability block` | — |
| `weekly.rules.onlineBlock.message` | `Each online-only availability block must be at least {dur}.` | `{dur}` |
| `weekly.rules.breaks.travel.label` | `Break ≥ travel time` | — |
| `weekly.rules.breaks.travel.message` | `Breaks between availability must be\nat least {brk} (your travel time).\nEdges may be {edge}.` | `{brk}`, `{edge}` |
| `weekly.rules.breaks.plain.label` | `Break between availability` | — |
| `weekly.rules.breaks.plain.message` | `Breaks between availability must be\nat least {brk}.\nEdges may be {edge}.` | `{brk}`, `{edge}` |
| `weekly.rules.window.label` | `Continuous availability window` | — |
| `weekly.rules.window.message` | `Workdays need one continuous availability window of at least {dur}.` | `{dur}` |

</details>

<details>
<summary>weekly.rulesDialog — 12 messages</summary>

| Key | Default English text | Placeholders / tags |
|---|---|---|
| `weekly.rulesDialog.title` | `Update calendar rules` | — |
| `weekly.rulesDialog.desc` | `These parameters come from the Services module. Editing them re-checks the calendar instantly.` | — |
| `weekly.rulesDialog.minAvailBlock` | `Min availability block` | — |
| `weekly.rulesDialog.minInpersonBlock` | `Min in-person block` | — |
| `weekly.rulesDialog.minOnlineBlock` | `Min online block` | — |
| `weekly.rulesDialog.minBreak` | `Min break between blocks` | — |
| `weekly.rulesDialog.continuousWindow` | `Continuous window` | — |
| `weekly.rulesDialog.maxDaysOffWeek` | `Max days off / week` | — |
| `weekly.rulesDialog.dayOne` | `{count} day` | `{count}` |
| `weekly.rulesDialog.dayOther` | `{count} days` | `{count}` |
| `weekly.rulesDialog.reset` | `Reset to defaults` | — |
| `weekly.rulesDialog.apply` | `Apply rules` | — |

</details>

<details>
<summary>weekly.guidelines — 11 messages</summary>

| Key | Default English text | Placeholders / tags |
|---|---|---|
| `weekly.guidelines.title` | `Setting up your weekly business hours` | — |
| `weekly.guidelines.intro` | `We strive to make you and your Clients happy. That's why setting up your availability correctly throughout the day is crucial.` | — |
| `weekly.guidelines.travel` | `Pick how long you need to get between clients (min. <hl>{travelMin}</hl> for your location). Do this first! Changing it later resets your calendar settings. Travel time becomes locked after your first booking.` | `<hl>`, `{travelMin}` |
| `weekly.guidelines.online` | `Select whether you'll work <hl>in-person</hl> at the client's location, <hl>online</hl> from anywhere, or a mix of both. You can combine both types throughout your day.` | `<hl>` |
| `weekly.guidelines.daysOff` | `Need a break? Grab up to {maxDaysOff} any <hl>DAYS OFF</hl> a week. You can set custom work hours for these days if you want. For other days your workday rules will apply.` | `{maxDaysOff}`, `<hl>` |
| `weekly.guidelines.cardWindow` | `Schedule for all <hl>WORKDAYS</hl> will be the same. Make sure your workdays have at least one <hl>continuous window of at least {window}</hl> when you're available for bookings.` | `<hl>`, `{window}` |
| `weekly.guidelines.cardBlocks` | `Any other <hl>availability</hl> slots must be <hl>at least {minBlock}</hl> long. Any <hl>breaks</hl> between your availability slots must be at least {minBreak}.` | `<hl>`, `{minBlock}`, `{minBreak}` |
| `weekly.guidelines.cardBlocksTravel` | `Any other <hl>availability</hl> slots must be <hl>at least {minBlock}</hl> long. Also, the <hl>breaks</hl> you take between your availability slots cannot be shorter than your chosen travel time.` | `<hl>`, `{minBlock}` |
| `weekly.guidelines.cardBlocksOnline` | `Any availability slots must be at least <hl>{minBlock}</hl> for in-person and <hl>{minOnline}</hl> for online sessions. Any breaks between availability slots can be <hl>{minBreak}</hl> or longer.` | `<hl>`, `{minBlock}`, `{minOnline}`, `{minBreak}` |
| `weekly.guidelines.cardBooking` | `We prevent double-booking, but sessions can be <hl>back-to-back</hl>. Please plan your schedule to ensure you arrive on time at the client's location for in-person sessions.` | `<hl>` |
| `weekly.guidelines.cardBookingTravel` | `To keep your rating high and prevent double-booking, we automatically <hl>add travel time</hl> to every session. You'll only ever be booked for <hl>one client at a time</hl>.` | `<hl>` |

</details>

<details>
<summary>weekly.coach — 6 messages</summary>

| Key | Default English text | Placeholders / tags |
|---|---|---|
| `weekly.coach.daysOff` | `Tap a day name to toggle a day off.` | — |
| `weekly.coach.tap` | `Tap a time slot to change its status.` | — |
| `weekly.coach.drag` | `Drag across slots to change several.` | — |
| `weekly.coach.title` | `How to edit your availability` | — |
| `weekly.coach.replay` | `Replay` | — |
| `weekly.coach.gotIt` | `Got it` | — |

</details>

<details>
<summary>annual — 4 messages</summary>

| Key | Default English text | Placeholders / tags |
|---|---|---|
| `annual.title` | `Select your annual work calendar` | — |
| `annual.instr1` | `Click on any day (or click and drag) to change its status` | — |
| `annual.instr2` | `Click on the year to change the year` | — |
| `annual.yearPickerTitle` | `Select the year` | — |

</details>

<details>
<summary>annual.legend — 5 messages</summary>

| Key | Default English text | Placeholders / tags |
|---|---|---|
| `annual.legend.availableLabel` | `Available` | — |
| `annual.legend.availableSub` | `(as per weekly business hours)` | — |
| `annual.legend.unavailableLabel` | `Unavailable` | — |
| `annual.legend.availableDesc` | `Clients who need your services during these days will be able to find and book you` | — |
| `annual.legend.unavailableDesc` | `Clients who need your services during these days will not be able to find you` | — |

</details>

<details>
<summary>annual.rules — 6 messages</summary>

| Key | Default English text | Placeholders / tags |
|---|---|---|
| `annual.rules.maxDaysOff.label` | `Maximum days off` | — |
| `annual.rules.maxDaysOff.message` | `You can select up to {max} days off per year` | `{max}` |
| `annual.rules.maxConsecutive.label` | `Maximum consecutive days off` | — |
| `annual.rules.maxConsecutive.message` | `You can take a maximum of {max} consecutive days off` | `{max}` |
| `annual.rules.minGap.label` | `Interval between time-off blocks` | — |
| `annual.rules.minGap.message` | `Leave at least {weeks} full calendar weeks (MO–SU) between non-consecutive days off` | `{weeks}` |

</details>

<details>
<summary>annual.guidelines — 6 messages</summary>

| Key | Default English text | Placeholders / tags |
|---|---|---|
| `annual.guidelines.title` | `Setting up your annual work calendar` | — |
| `annual.guidelines.intro` | `We strive to make you and your Clients happy. Thus, each calendar year you can select <hl>up to {maxDaysOffPerYear} calendar days (MO-SU) as days off</hl> to make yourself unavailable for booking.` | `<hl>`, `{maxDaysOffPerYear}` |
| `annual.guidelines.cardConsecutive` | `You can take a <hl>maximum of {maxConsecutive} consecutive days off</hl>` | `<hl>`, `{maxConsecutive}` |
| `annual.guidelines.cardInterval` | `The interval between any non-consecutive days off must be at least <hl>{minGapWeeks} full calendar weeks from MO to SU</hl>` | `<hl>`, `{minGapWeeks}` |
| `annual.guidelines.cardBookings` | `You can select days off only in the future and only in those weeks during which you have <hl>no bookings</hl>, completed <sqCompleted></sqCompleted> or scheduled <sqScheduled></sqScheduled>` | `<hl>`, `<sqCompleted>`, `<sqScheduled>` |
| `annual.guidelines.cardDiscuss` | `While you can adjust your annual work calendar at any time, we recommend that you always <hl>discuss and agree on vacation times with your Clients</hl>` | `<hl>` |

</details>

<details>
<summary>annual.coach — 7 messages</summary>

| Key | Default English text | Placeholders / tags |
|---|---|---|
| `annual.coach.title` | `How to edit your annual calendar` | — |
| `annual.coach.tap` | `Tap individual days to select or clear days off.` | — |
| `annual.coach.drag` | `Drag to select multiple days.` | — |
| `annual.coach.dragClear` | `Drag across selected days to clear them.` | — |
| `annual.coach.switchYear` | `Tap the year once to switch years` | — |
| `annual.coach.replay` | `Replay` | — |
| `annual.coach.gotIt` | `Got it` | — |

</details>

## Theming

The calendars ship a complete default look: every colour, the radius, the fonts and the dialog widths are `--cal-*` CSS variables defined on `:root`, with dark values under `.dark` / `[data-theme="dark"]`. A portal that changes nothing gets the default calendar. The theme bundles two font families locally: Manrope for Latin text and IBM Plex Sans Arabic for Arabic.

To change the look, pass only the values you want through the `theme` prop. Everything you leave out keeps the calendar default:

```tsx
import type { CalendarTheme } from "@abapro-front-end/calendars";

const theme: CalendarTheme = {
  accent: "var(--primary)",
  unavailable: "var(--danger)",
  font: "var(--font-sans)",
  stickyTop: "var(--topbar-height, 0px)",
};

<WeeklyCalendar value={week} onChange={setWeek} theme={theme} />;
```

The values are applied to that calendar's root and to its dialogs, menus and year indicator (they render in a portal), so they never leak into the rest of the page. They can point at your own CSS variables, which keeps your dark mode working. Unknown keys and empty values are ignored. For standalone parts used outside a calendar root (`WeeklyGuidelinesDialog`, `NoticeDialog`, `WeeklyLegend`, `AnnualLegend`, ...), wrap them in `<CalendarThemeProvider theme={theme}>`. To theme an element of your own, `calendarThemeStyle(theme)` returns the same `--cal-*` variables as an inline `style` object.

Tokens (`CALENDAR_THEME_TOKENS`; each key maps to `--cal-<kebab-case-key>`, e.g. `mutedForeground` to `--cal-muted-foreground`, see `themeVariable`): `surface`, `muted`, `foreground`, `mutedForeground`, `border`, `borderStrong`, `input`, `ring`, `accent`, `accentForeground`, `available`, `availableHover`, `weekend`, `weekendHover`, `past`, `pastForeground`, `unavailable`, `unavailableForeground`, `online`, `violation`, `secondary`, `secondaryForeground`, `overlay` (dialog backdrop), `radius` (the `rounded-cal-xs` to `rounded-cal-xl` steps scale from it), `font`, `fontWeight`, `fontFeatures`, `headingSpacing`, `dialogWidth`, `dialogMobileWidth`, `annualDialogWidth`, `annualDialogMobileWidth` and `stickyTop` (offset for the sticky day header under a fixed app bar).

Setting the same `--cal-*` variables in a stylesheet still works, but they then apply to every calendar on the page. Keep calendar tokens for the calendar: the portal's own components should use the portal's tokens, not `--cal-*`.

Weekly desktop dialogs default to 384px; annual guidelines use 390px (345px on mobile). Custom guideline messages can include `\n` for explicit line breaks. Travel-time notification paragraphs wrap naturally.

Clicking the annual year label cycles through `years` immediately and shows a fading year indicator at the bottom. Leave selections are retained across years. `AnnualCalendar.YearPicker` remains available for custom compositions that need a dialog.

The annual onboarding demo shows four steps: a click that selects one day, a finger drag that extends it into a block of consecutive days, a drag that clears the last two days of that block, and a tap on the year that switches to the next year and back, with a rising, fading year indicator. Every step shows one block of consecutive days, and it ends on four of them, a selection the rulebook's Therapist and Analyst rule sets accept. The demo does not read the calendar's `rules` or `today`, so a portal with tighter limits (for example fewer than six consecutive days) should keep that in mind. Its gesture effects and footer match the weekly demo. Both demos show step instructions only during playback; the initial and finished previews have no instruction banner. It opens with the default calendar and can be replayed from the header help button. It never changes schedule data and respects reduced-motion preferences. In a custom composition, use `<AnnualCalendar.Coach />` for help-only access or `<AnnualCalendar.Coach defaultOpen />` to open it initially. Dragging from a day selects dates on touch screens; start a gesture outside the day buttons to scroll.

## Composing your own layout

The default components are compositions of parts over a provider. Use the parts to re-order, drop or add pieces:

```tsx
import {
  WeeklyCalendarRoot,
  WeeklyCalendarGrid,
  WeeklyCalendarStatus,
  WeeklyCalendarNotices,
  useWeeklyCalendar,
} from "@abapro-front-end/calendars/weekly";

function SaveButton() {
  const { actions, meta } = useWeeklyCalendar();
  return <button onClick={() => actions.save()}>{meta.messages.common.save}</button>;
}

<WeeklyCalendarRoot value={week} onChange={setWeek} onSave={save}>
  <WeeklyCalendarGrid />
  <WeeklyCalendarStatus />
  <WeeklyCalendarNotices />
  <SaveButton />
</WeeklyCalendarRoot>;
```

Parts: `Root`, `Header`, `Controls`, `Grid`, `Status`, `SaveBar`, `Guidelines`, `Coach`, `Notices`, `RulesDialog` for weekly; `Root`, `Header`, `Legend`, `Grid`, `Status`, `Guidelines`, `YearPicker`, `Coach` for annual. They are also reachable as statics (`WeeklyCalendar.Grid`) in client code. Standalone pieces for galleries: `WeeklyGuidelinesDialog`, `AnnualGuidelinesDialog`, `NoticeDialog`, `NoticeHl`, `WeeklyLegend`, `AnnualLegend`. The three dialogs take their own `portalContainer` prop; inside a calendar root they inherit the root's portal target and direction, and the guidelines dialogs used on their own take their direction from `locale`.

For a custom weekly day header, `meta` has three day-name lists, Monday first: `weekdayLabels` (the header text: `MO`, `TU`, ... or full names in Arabic), `weekdayNames` (full names, used for screen-reader labels and the save error) and `weekdays` (short names, `Mon`, `Tue`, ...).

## Icons

The icons from the guideline dialogs are exported, so a portal can reuse them instead of copying the SVGs:

```tsx
import { ClockCogIcon } from "@abapro-front-end/calendars/icons";

<ClockCogIcon className="size-8 text-cal-accent" />;
```

- Available: `CalendarAgendaIcon`, `CalendarClockIcon`, `CalendarDayOffIcon`, `CalendarDotsIcon`, `CalendarStarIcon`, `ClockCogIcon`, `ClockDollarIcon`, `UsersIcon`, and `CloseCircleIcon` (the guidelines close button). The package root exports them too.
- Each takes normal SVG props and has no size of its own, so always pass one (the guidelines use `size-8`). The viewBox is 34×34, or 20×20 for `CloseCircleIcon`.
- Lines follow `currentColor`. A few details use calendar tokens from `theme.css`: `CalendarDotsIcon` (`--cal-border-strong`, `--cal-unavailable`) and `CloseCircleIcon` (`--cal-accent`, `--cal-accent-foreground`).
- They render with `aria-hidden="true"`, as decorative icons.

## Data adapters

`@abapro-front-end/calendars/adapters` gives the controlled components a backend without baking HTTP into them:

```tsx
import { createRestScheduleApi, useSchedule } from "@abapro-front-end/calendars/adapters";

const api = createRestScheduleApi<WeeklySchedule>({
  loadUrl: (id) => `/api/specialists/${id}/weekly`,
  saveUrl: (id) => `/api/specialists/${id}/weekly`,
  headers: () => ({ Authorization: `Bearer ${token()}` }),
});

const schedule = useSchedule(api, specialistId);
schedule.value && <WeeklyCalendar value={schedule.value} onChange={schedule.setValue} />;
```

`createMemoryScheduleApi(seed, empty)` is the placeholder for portals without endpoints yet. `useSchedule` returns `{ value, status, error, setValue, reload }` with `status` in `loading | ready | saving | error`.

Within a `useSchedule` instance, edits are saved in order for each API and schedule ID. The status stays `saving` until the latest edit finishes; an older failure does not cancel newer queued edits. Reloads wait for pending saves. Concurrent editing from separate hook instances or clients still requires server-side conflict handling.

## Development

```sh
nvm use            # Node 24
npm install
npm test           # Vitest + Testing Library
npm run lint
npm run typecheck
npm run build      # tsc → dist/
npm run playground # Vite app at http://localhost:5173
npm run pack:local # timestamped tarball in .packs/ for portals
```

### Handing out a tarball (temporary, until the first release)

1. Make sure `npm test`, `npm run lint` and `npm run typecheck` pass.
2. Run `npm run pack:local`. It builds `dist/`, names the tarball by its UTC build time (`abapro-front-end-calendars-<version>-<yyyymmdd-hhmmss>.tgz`) and keeps only the newest one in `.packs/`.
3. Send that file to the portal teams with a short change note, and call out anything breaking (renamed props, message keys or exports).
4. Portal teams follow [Update to a newer build](#update-to-a-newer-build).

The version stays `0.0.0` until the first release, so the build time in the file name is what tells builds apart.

### Releases

Releases use changesets. Add one with `npm run changeset` in each merge request. To release, run `npm run version` (bumps the version and writes `CHANGELOG.md`) and merge that to `main`; the pipeline publishes any version not yet in the registry. The release job runs only on `main` and skips publishing while unapplied changesets remain in `.changeset/`. Publishing only runs in GitLab CI: `prepublishOnly` stops a local `npm publish`.

## Backlog

- Keyboard painting in the weekly grid.
- `validators`, `readOnly` and per-slot `classNames` props (deferred until a portal needs them).
- Storybook or a hosted playground.
